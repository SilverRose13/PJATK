package MAS.MP2_Socha_Maria_s19701.qualified_association;

public class DogDescription {
    //this is what we want to get when the vetClinic searches by chip
    private String description;

    public DogDescription(String description) {
        this.description = description;
    }


    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


}
