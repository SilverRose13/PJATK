package MAS.MP3_Socha_Maria_s19701.Overlapping;

public enum PetType {
    DOG, CAT
}
