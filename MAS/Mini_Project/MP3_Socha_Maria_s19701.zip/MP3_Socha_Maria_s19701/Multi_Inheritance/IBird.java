package MAS.MP3_Socha_Maria_s19701.Multi_Inheritance;

public interface IBird {
    //this interface is created based on the Bird class
    //it is meant to make possible for Pegasus to have multiple inheritance
    public boolean hasChicks();
}
