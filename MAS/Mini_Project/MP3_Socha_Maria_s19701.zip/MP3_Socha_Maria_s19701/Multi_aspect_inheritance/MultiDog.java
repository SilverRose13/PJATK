package MAS.MP3_Socha_Maria_s19701.Multi_aspect_inheritance;

public class MultiDog extends MultiPet{

    public MultiDog(String name) {
        //child class
        //takes the constructor and all methods from parent class (Pet)
        super(name);
    }    
    
}
