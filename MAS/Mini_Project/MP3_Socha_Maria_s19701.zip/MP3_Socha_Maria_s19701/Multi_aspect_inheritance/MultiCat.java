package MAS.MP3_Socha_Maria_s19701.Multi_aspect_inheritance;

public class MultiCat extends MultiPet {

    public MultiCat(String name) {
        //child class
        //takes the constructor and all methods from parent class (Pet)
        super(name);
    }
    
}
