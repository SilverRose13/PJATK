package MAS.MP3_Socha_Maria_s19701.Multi_aspect_inheritance;

public interface Male {
    //only males are neutered
    public boolean isNeutered();
}
