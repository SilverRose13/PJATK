package MAS.MP3_Socha_Maria_s19701.Abstract_Inheritance;

public class AbstractInheritanceDog extends AbstractInheritancePet{
    //child class
    //takes the constructor and all methods from parent class (Pet)

    public AbstractInheritanceDog(String name) {
        super(name);
    }    
    
}
