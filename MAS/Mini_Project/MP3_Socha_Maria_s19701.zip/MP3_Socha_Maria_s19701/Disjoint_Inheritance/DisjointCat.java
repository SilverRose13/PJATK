package MAS.MP3_Socha_Maria_s19701.Disjoint_Inheritance;

public class DisjointCat extends DisjointPet {

    public DisjointCat(String name) {
        //child class
        //takes the constructor and all methods from parent class (Pet)
        super(name);
    }
    
}
